DROP TABLE IF EXISTS `#__brafton_categories`;
DROP TABLE IF EXISTS `#__brafton_content`;
DROP TABLE IF EXISTS `##__brafton_options`;