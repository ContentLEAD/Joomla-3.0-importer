<?php 
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>

<pre><?php if ($this->logContents) echo $this->logContents; ?></pre>
