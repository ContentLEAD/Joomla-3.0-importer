<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h1>Brafton Article Importer</h1>
